﻿using NUnit.Framework;

namespace PartsTrader.ClientTools.Tests
{
    /// <summary>
    /// Tests for <see cref="PartCatalogue" />.
    /// </summary>
    [TestFixture]
    public class PartCatalogueTests
    {
        //TODO: include your unit tests here
    }
}