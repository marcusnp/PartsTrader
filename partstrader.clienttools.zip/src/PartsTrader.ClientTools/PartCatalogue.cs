﻿using System;
using System.Collections.Generic;
using PartsTrader.ClientTools.Api;
using PartsTrader.ClientTools.Api.Data;

namespace PartsTrader.ClientTools
{
    public class PartCatalogue : IPartCatalogue
    {
        public IEnumerable<PartSummary> GetCompatibleParts(string partNumber)
        {
            //TODO: implement

            throw new NotImplementedException();
        }
    }
}